<?php
/**
 * @file
 * View template for the class admin view.
 *
 * @param array $data
 * 	Contains the data passed from the controller.
 */
?>

<h1><?php _e('Class Management', 'weekly-class-schedule'); ?></h1>